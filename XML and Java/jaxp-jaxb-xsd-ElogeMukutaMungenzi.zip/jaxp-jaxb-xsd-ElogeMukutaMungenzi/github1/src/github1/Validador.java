/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package github1;


import java.io.File;

public class Validador {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {

Validador validador = new Validador();
		validador.valida(new File("ListaDebooks.xml"), new File("SeriesTv.xsd"));
        
    }

    private void valida(File file, File file0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
