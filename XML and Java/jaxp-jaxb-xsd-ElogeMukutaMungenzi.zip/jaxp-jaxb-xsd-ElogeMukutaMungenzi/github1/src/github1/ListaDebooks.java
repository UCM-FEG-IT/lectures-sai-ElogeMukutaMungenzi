/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package github1;


 
public class ListaDebooks {
    private String title;
    private String note;
    private int quantity;
    private float price;
    
    public String gettitle(){
      return title;
    } 
    public void Settitle(String title) {
        this.title  = title;
    }
    
    public String getnote() {
        return note;
    }
    public void setnote(String note) {
        this.note = note;
    }
    
    public int getquantity() {
        return quantity;
    }
    public void set(int quantity) {
        this.quantity = quantity;
    }
    public float getprice() {
        return price;
    }
    public void setprice(float price) {
        this.price = price;
    }

    void settitle(float tagValue) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void title(float tagValue) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void Setquantity(String tagValue) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void Setprice(String tagValue) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void Setnote(String tagValue) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}